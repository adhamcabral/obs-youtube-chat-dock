# Chat Dock for OBS

Plugin simples para OBS Studio que cria um dock chamado `Chat`.

Você cola o link de um canal do YouTube uma vez. O plugin verifica
periodicamente a URL `/live` desse canal e, quando encontra uma live ativa,
carrega automaticamente o chat pop-out da live dentro do dock do OBS.

## O que ele faz

- Aceita links como `https://www.youtube.com/@canal` ou
  `https://www.youtube.com/channel/UC...`.
- Também aceita links diretos de vídeo/live.
- Salva o último canal configurado.
- Verifica automaticamente a cada 30 segundos.
- Atualiza o dock automaticamente só quando o vídeo da live muda.
- Recolhe os controles quando o chat carrega; use o botão `v` para mostrar de
  novo.
- O botão `Checar` força nova verificação e recarrega o chat da live atual.
- Quando a live termina ou deixa de ser detectada, volta para a tela de espera
  após algumas verificações.

## Dependências

- OBS Studio com headers de desenvolvimento.
- OBS Studio 30 ou mais novo.
- CMake 3.22+.
- Qt 6.4+ com `Widgets` e `Network`.
- Pacote de desenvolvimento do `obs-frontend-api`.
- Plugin `obs-browser` disponível no OBS.

No Linux, browser docks do OBS/CEF precisam rodar em X11/XWayland. Em sessão
Wayland, inicie o OBS com:

```sh
QT_QPA_PLATFORM=xcb obs
```

No Windows, o instalador apenas copia um `chat-dock.dll` ja compilado para a
pasta global de plugins do OBS em `C:\ProgramData\obs-studio\plugins`.

O binario Windows distribuido em `dist\windows\chat-dock.dll` e compilado
contra OBS 32.0.x para funcionar nas versoes OBS 32.x enquanto a ABI do OBS e
do `obs-browser` permanecer compativel.

## Instaladores

Os arquivos em `executaveis/` instalam o plugin no perfil do OBS. No Linux eles
tambem compilam o `.so`; no Windows o `.dll` precisa estar pronto.

Linux normal:

```sh
./executaveis/linuxplugin
```

Linux com OBS Flatpak:

```sh
./executaveis/flatpaklinuxplugin
```

Windows:

```bat
executaveis\windowsplugin.bat
```

No Linux normal, o script suporta `pacman`, `apt-get`, `dnf` e `zypper`.

No Flatpak, o script compila dentro do ambiente do proprio OBS Flatpak usando
`flatpak run --devel com.obsproject.Studio`. Isso evita instalar um `.so`
compilado contra as bibliotecas do sistema normal. Rode esse script a partir da
raiz do projeto; ele usa a pasta `build-flatpak`.

No Windows, coloque `chat-dock.dll` em `dist\windows\chat-dock.dll` ou na mesma
pasta de `windowsplugin.bat`. O instalador cria a pasta do plugin e copia o
arquivo para `%ProgramData%\obs-studio\plugins`. Dependendo das permissoes do
Windows, pode ser necessario executar o `.bat` como administrador.

Feche o OBS antes de instalar ou atualizar o plugin, pois o Windows bloqueia a
substituicao de DLLs que estejam carregadas pelo OBS.

## Build

Exemplo genérico:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
cmake --install build --prefix "$HOME/.config/obs-studio/plugins"
```

No Windows, use o prefixo global de plugins do OBS:

```bat
cmake --install build --prefix "%ProgramData%\obs-studio\plugins"
```

Se o CMake não encontrar `libobs` ou `obs-frontend-api`, passe o caminho do
OBS instalado/compilado com `CMAKE_PREFIX_PATH`, por exemplo:

```sh
cmake -S . -B build -DCMAKE_PREFIX_PATH="/caminho/para/obs/cmake/prefix"
```

## Estrutura

- `src/plugin-main.cpp`: ciclo de vida do plugin OBS e registro do dock.
- `src/chat-dock.*`: UI do dock, polling e atualização do chat.
- `src/detector.*`: normalização de URLs e detecção do ID da live.
- `src/obs-browser-panel.*`: ponte para o CEF interno do `obs-browser`.

## Uso

1. Instale o plugin.
2. Abra o OBS.
3. Abra `Docks > Chat`.
4. Cole o link do canal.
5. Clique em `Salvar` ou `Checar`.

Quando o canal entrar ao vivo, o dock carrega:

```text
https://www.youtube.com/live_chat?v=VIDEO_ID&is_popout=1
```

## Limitações

Este plugin usa a página pública do YouTube para descobrir a live. Isso mantém
o uso simples e evita chave de API, mas pode quebrar se o YouTube mudar o HTML
da página. Para uma versão mais robusta, o ideal é usar YouTube Data API com uma
chave configurável.

A primeira versão tentava embutir o chat com `Qt WebEngine`, mas isso causava
segfault no OBS em algumas sessões Linux/Wayland. A versão atual usa o CEF do
`obs-browser`, o mesmo mecanismo dos Browser Docks oficiais do OBS.
